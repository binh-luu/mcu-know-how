# Expense Reporting Assistant Chatbot

A multi-turn, function-calling chatbot that helps employees manage expense reports, query company policies, and calculate reimbursements — built entirely with the OpenAI Python SDK.

---

## Table of Contents

1. [Concept Design](#1-concept-design)
2. [How It's Implemented](#2-how-its-implemented)
3. [Usage Guide](#3-usage-guide)

---

## 1. Concept Design

### 1.1 Problem Statement

Employees find expense reporting complex and time-consuming, leading to errors, policy violations, and delayed reimbursements. This chatbot addresses that problem by providing a natural-language interface to:

- **Look up** company expense policies instantly
- **Submit** expense entries with automatic policy validation
- **Calculate** reimbursements with transparent, step-by-step rule application
- **Manage** existing expenses (view, delete)
- **Summarize** department-level spending

### 1.2 Architecture Overview

```
┌──────────────────────────────────────────────────────────────┐
│                      User (CLI Terminal)                     │
└──────────────────────────────────┬───────────────────────────┘
                                   │ typed messages
                                   ▼
┌──────────────────────────────────────────────────────────────┐
│                   ExpenseChatbot (Main Class)                │
│  ┌───────────────────────────────────────────────────────┐   │
│  │              ConversationManager                      │   │
│  │  • Bounded message history (max 30 messages)          │   │
│  │  • System prompt with few-shot examples               │   │
│  │  • Chain-of-thought reasoning instructions            │   │
│  │  • Function-call roundtrip loop                       │   │
│  └───────────────┬───────────────────────┬───────────────┘   │
│                  │                       │                   │
│    ┌─────────────▼─────────────┐  ┌──────▼───────────────┐   │
│    │   OpenAI / Azure Client   │  │  Output Formatters   │   │
│    │  • chat.completions       │  │  • Expense tables    │   │
│    │  • tools (function def.)  │  │  • Policy bullets    │   │
│    │  • parallel_tool_calls    │  │  • Receipt blocks    │   │
│    └─────────────┬─────────────┘  └──────────────────────┘   │
│                  │                                           │
└──────────────────┼───────────────────────────────────────────┘
                   │ tool call dispatch
                   ▼
┌──────────────────────────────────────────────────────────────┐
│                    Tool Handlers                             │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────────────┐  │
│  │ query_policy │ │ submit_exp   │ │ calc_reimbursement   │  │
│  └──────────────┘ └──────────────┘ └──────────────────────┘  │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────────────┐  │
│  │ get_expenses │ │ delete_exp   │ │ dept_summary         │  │
│  └──────────────┘ └──────────────┘ └──────────────────────┘  │
│                                                              │
│              Policy Engine + Mock Data Layer                 │
│  • EXPENSE_POLICY_FAQS     (8 policy rules)                  │
│  • MOCK_EXPENSE_REPORTS    (6 pre-seeded entries)            │
│  • EMPLOYEE_DIRECTORY      (3 employees)                     │
│  • CATEGORY_CAPS           (per-category reimbursement caps) │
└──────────────────────────────────────────────────────────────┘
```

### 1.3 Tool (Function) Overview

| # | Tool Name | Purpose | Key Parameters |
|---|---|---|---|
| 1 | `query_expense_policy` | Search policies by keyword | `topic` (string) |
| 2 | `calculate_reimbursement` | Compute reimbursement with per-line-item breakdown | `expenses` (array of `{category, amount, date}`) |
| 3 | `get_employee_expenses` | List all expenses for an employee | `employee_id` (string) |
| 4 | `submit_expense` | Add a new expense with policy validation | `employee_id, date, category, amount, description` |
| 5 | `delete_expense` | Remove an expense by index | `employee_id, expense_index` |
| 6 | `get_department_summary` | Aggregate spending by department | `department` (string) |

The model decides **which tool(s) to call** based on the user's natural-language request. Multiple tools can be called in parallel (e.g., `get_employee_expenses` followed by `calculate_reimbursement`).

### 1.4 Few-Shot Prompting Strategy

The system prompt embeds **four detailed few-shot examples** covering every major intent:

| Example | Scenario | Demonstrates |
|---|---|---|
| 1 | "What's the daily meal limit?" | Policy query → `query_expense_policy` → policy bullet response |
| 2 | "Submit a $45 meal expense for E123" | Expense submission → `submit_expense` → receipt block with warnings |
| 3 | "Calculate my reimbursement for E123" | Multi-step: `get_employee_expenses` → `calculate_reimbursement` → breakdown table |
| 4 | "I spent money on food yesterday" | Ambiguous input → clarifying questions (no tool call) |

Each example shows: the user input, which tool(s) are called, the tool result, and how the assistant formats its final reply. This teaches the model the expected behaviour for each intent **without requiring separate training data**.

### 1.5 Chain-of-Thought Reasoning

The system prompt instructs the model to **reason step-by-step** before answering:

- **Policy queries**: "Identify which rules match → explain each matching rule → state the answer."
- **Reimbursement**: "For each line item → state category, amount, applicable cap/rule, reimbursed amount → sum total."
- **Submissions**: "Check each policy rule against the entry → list warnings."

This reasoning is reinforced by the **tool handler outputs**: `calculate_reimbursement` returns a structured `reasoning` field with per-line-item calculations, and `query_expense_policy` returns a `reasoning` field describing the matching process. The model uses this to generate transparent, step-by-step responses.

### 1.6 Mock Data Schema

```python
# Expense Policy FAQs
EXPENSE_POLICY_FAQS: list[{
    "topic": str,           # e.g. "meal", "travel", "receipt"
    "rule": str,            # full policy text
}]

# Expense Reports
MOCK_EXPENSE_REPORTS: list[{
    "employee_id": str,     # e.g. "E123"
    "date": str,            # YYYY-MM-DD
    "category": str,        # Meals, Taxi, Travel, Lodging, Entertainment
    "amount": float,        # USD
    "description": str,
}]

# Employee Directory
EMPLOYEE_DIRECTORY: dict[str, {
    "name": str,
    "department": str,
}]

# Reimbursement Caps
CATEGORY_CAPS: dict[str, float]  # e.g. {"meals": 50.0, "lodging": 200.0}
FULLY_REIMBURSED: list[str]      # e.g. ["taxi", "travel"]
```

### 1.7 Policy Rules

| Rule | Detail |
|---|---|
| Receipt threshold | Required for all expenses above $25 |
| Meal cap | $50 per day |
| Lodging cap | $200 per night |
| Travel pre-approval | Must be approved before booking |
| Taxi trip log | Pickup, drop-off, and business purpose required |
| Entertainment cap | $75 per event; client name + company required |
| Submission deadline | By 5th business day of following month |
| Currency | International expenses reported in USD |

---

## 2. How It's Implemented

### 2.1 Code Organisation

The single `expense_chatbot.py` file is structured into 12 clearly separated sections:

| Section | Lines | Description |
|---|---|---|
| 1. Imports | Standard library + `openai` | Graceful fallback if `openai` not installed |
| 2. Configuration | Constants, ANSI colours | `MODEL_NAME`, `MAX_MESSAGE_HISTORY`, CLI formatting |
| 3. Mock Data | Policy FAQs, expenses, employees | In-memory "database" simulating a real system |
| 4. Policy Engine | `_policy_warnings()`, `_calculate_breakdown()` | Pure functions — no side effects, easy to test |
| 5. Output Formatters | `_format_table()`, `format_*()` | ASCII tables, bullet points, receipt blocks |
| 6. Tool Definitions | `TOOLS` list | OpenAI JSON schema for 6 function-calling tools |
| 7. Tool Handlers | `_handle_tool_call()` | Dispatch + business logic for each tool |
| 8. System Prompt | `SYSTEM_PROMPT` | Policy rules, few-shot examples, CoT instructions |
| 9. Client Factory | `create_client()` | Auto-detects Azure vs. standard OpenAI |
| 10. Conversation Manager | `ConversationManager` class | Message history, tool-call loop, log capture |
| 11. Chatbot Class | `ExpenseChatbot` class | CLI REPL, demo mode, `/commands` |
| 12. Entry Point | `main()` | Argument parsing, mode selection |

### 2.2 Key Patterns

#### Function Calling Roundtrip

```
User input
    │
    ▼
┌─────────────────────────────────┐
│  client.chat.completions.create │  ← sends messages + tools definition
│  tools=TOOLS                    │
│  parallel_tool_calls=True       │  ← enables batching
└─────────────┬───────────────────┘
              │
              ▼
    ┌────────────────────┐
    │ Model response     │
    └────────┬───────────┘
             │
      ┌──────┴──────┐
      │             │
  tool_calls    plain text
      │             │
      ▼             ▼
 Execute tools   →  Return to user
      │
      ▼
 Append tool results
 to message history
      │
      ▼
 Loop back to API   ← model sees tool results, generates final text
      │
      ▼
  Final text response
```

The loop runs up to `MAX_FUNCTION_CALL_ITERATIONS` (5) per user turn, handling chains like: user says "show me E456's reimbursement" → `get_employee_expenses` → `calculate_reimbursement` → final answer.

#### Parallel Tool Calls (Batching)

`parallel_tool_calls=True` allows the model to emit **multiple tool calls in a single response**. For example, "show me Engineering's summary and calculate Alice's reimbursement" could trigger `get_department_summary` and `get_employee_expenses` simultaneously. The `_execute_tool_calls` method iterates over all `tool_calls` in the response and executes each one, collecting results before sending them back to the model.

#### Bounded Conversation History

The `ConversationManager` maintains a sliding window of up to `MAX_MESSAGE_HISTORY` (30) messages. When exceeded, the oldest messages are trimmed while the system prompt is always preserved. This prevents context overflow while keeping recent conversation context intact.

#### Policy Validation

When `submit_expense` is called, `_policy_warnings(entry)` checks every rule:

```python
if amount > 25:
    → "Receipt required"
if category == "travel":
    → "Pre-approval required"
if category == "taxi":
    → "Trip log required"
if category in CATEGORY_CAPS and amount > cap:
    → "Excess not reimbursable"
```

The tool returns `success: True` with any warnings — the model then presents both the confirmation and the warnings to the user.

#### Reimbursement with Chain-of-Thought

`_calculate_breakdown()` returns a structured result:

```json
{
  "items": [
    {"category": "Meals", "amount": 45, "reimbursed": 45, "cap_note": "Cap: $50.00/day"},
    {"category": "Taxi",  "amount": 30.50, "reimbursed": 30.50, "cap_note": "Fully reimbursed"}
  ],
  "total": 75.50,
  "reasoning": "Step-by-step:\n  Meals: $45.00. Policy cap is $50.00. Reimbursed = $45.00.\n  Taxi: $30.50. Fully reimbursed.\nTotal = $75.50."
}
```

The model receives this structured breakdown and narrates it step-by-step in the final response.

### 2.3 Prompt Template

The system prompt is constructed in the `SYSTEM_PROMPT` constant and contains:

1. **Role definition** — "You are the Expense Reporting Assistant..."
2. **Capability list** — 6 things the bot can do
3. **Full policy rules** — all 8 rules embedded verbatim
4. **Chain-of-thought instructions** — "Before answering, ALWAYS reason through..."
5. **Four few-shot examples** — covering policy query, submission, reimbursement, and ambiguous input
6. **Behavior rules** — ask clarifying questions, present step-by-step, be concise

This is sent as the first message in every conversation (`role: system`) and never trimmed from history.

---

## 3. Usage Guide

### 3.1 Prerequisites

- **Python 3.10+** (type hints use `list[str]`, `dict[str, ...]` syntax)
- **OpenAI API key** (standard or Azure)

### 3.2 Installation

```bash
pip install openai
```

That's the only dependency. The script uses the standard library for everything else.

### 3.3 Environment Setup

Set one of the following API key configurations:

**Option A — Standard OpenAI:**
```bash
export OPENAI_API_KEY="sk-..."
```

**Option B — Azure OpenAI:**
```bash
export AZURE_OPENAI_API_KEY="your-azure-key"
export AZURE_OPENAI_ENDPOINT="https://your-resource.openai.azure.com/"
```

Optional overrides:
```bash
export MODEL_NAME="gpt-4o-mini"     # default
export API_VERSION="2024-07-01-preview"  # Azure only, default
```

### 3.4 Running the Chatbot

#### Interactive Mode

```bash
python expense_chatbot.py
```

Starts an interactive REPL:

```
╔══════════════════════════════════════════════════════════╗
║     Expense Reporting Assistant — Powered by OpenAI     ║
╠══════════════════════════════════════════════════════════╣
║  Type your message, or /help for commands.              ║
╚══════════════════════════════════════════════════════════╝

You: What is the meal expense limit?

Assistant:
The daily meal expense limit is $50 per day...
```

#### Demo Mode (Test Cases)

```bash
python expense_chatbot.py --demo
```

Runs all four test cases non-interactively and saves the full conversation log to `conversation_logs.json`:

```
=== Expense Reporting Assistant — Demo Mode ===

============================================================
  TC_01: Ask chatbot about expense policies → accurate, policy-based reply

  User: What is the meal expense limit?
  [tool] query_expense_policy({"topic": "meal"})
  Assistant: The daily meal expense limit is $50 per day...

...

✅ Demo complete. Conversation logs saved to conversation_logs.json
```

### 3.5 CLI Commands

| Command | Description |
|---|---|
| `/help` | List all available commands |
| `/clear` | Clear conversation history (fresh context) |
| `/log [file]` | Save conversation log to JSON (default: `conversation_logs.json`) |
| `/employees` | List known employees in the directory |
| `/expenses` | Show all current expense entries as a table |
| `/policy` | Show all expense policies |
| `/quit`, `/exit` | Exit the chatbot |

### 3.6 Example Conversations

#### Policy Query
```
You: Do I need a receipt for a $20 coffee?
Assistant: No — receipts are only required for expenses above $25. Your $20 coffee expense
          does not need a receipt attached.
```

#### Expense Submission
```
You: Submit a $75 meal expense for E123 on 2025-05-10. Team dinner.
Assistant: ✅ Expense submitted successfully!
           ⚠ Policy Warnings:
             • Receipt required (amount $75.00 > $25).
             • Per-diem cap for meals is $50.00; excess of $25.00 will not be reimbursed.
```

#### Reimbursement Calculation
```
You: Calculate my reimbursement for E123.
Assistant: Here's your reimbursement breakdown for Alice Johnson (E123):

           Reimbursement Calculation

           • Meals: $45.00 → reimbursed $45.00 (Cap: $50.00/day)
           • Taxi: $30.50 → reimbursed $30.50 (Fully reimbursed)

           Total Reimbursement: $75.50
```

#### Ambiguous Input
```
You: I spent some money on food yesterday.
Assistant: I'd be happy to help you submit that expense! I need a few more details:
           1. What's your employee ID?
           2. How much did you spend?
           3. What was a brief description?
```

### 3.7 Test Case Scenarios

| Test ID | Scenario | How to Run | Expected Result |
|---|---|---|---|
| TC_01 | Ask about expense policies | "What is the meal expense limit?" | Accurate policy-based reply with rule citation |
| TC_02 | Submit expenses + calculate reimbursement | Submit a new expense, then "calculate reimbursement for E123" | Policy-capped total with per-line-item breakdown |
| TC_03 | Ambiguous/incomplete input | "I spent some money on food yesterday" | Bot asks clarifying questions, does not call tools |
| TC_04 | Multi-turn context preserved | Submit expense → calculate → delete → verify deleted | All steps maintain context from previous turns |

Run all four automatically: `python expense_chatbot.py --demo`

### 3.8 Output Artifacts

| File | When Created | Contents |
|---|---|---|
| `conversation_logs.json` | After `--demo` runs, or `/log` command | Full message history with timestamps, tool calls, and responses |

### 3.9 Troubleshooting

| Problem | Solution |
|---|---|
| `ERROR: The 'openai' package is required` | Run `pip install openai` |
| `WARNING: No API key found` | Set `OPENAI_API_KEY` or Azure env vars |
| `401 Unauthorized` | Verify your API key is correct and has not expired |
| `429 Rate limit` | Wait a moment and retry; OpenAI has per-minute limits |
| Model doesn't call tools | Ensure model supports function calling (gpt-4o-mini, gpt-4o, gpt-3.5-turbo all do) |
| Colors not showing | Ensure terminal is a TTY; pipe to file and colours auto-disable |
| Demo mode fails silently | Check that environment variables are set; run without `--demo` to see errors interactively |

### 3.10 Extending the Chatbot

- **Add more policies**: Append to `EXPENSE_POLICY_FAQS`
- **Add more employees**: Append to `EMPLOYEE_DIRECTORY`
- **Add a new tool**: Define the JSON schema in `TOOLS`, add a handler branch in `_handle_tool_call()`, add a formatter in Section 5
- **Connect to real data**: Replace in-memory `MOCK_EXPENSE_REPORTS` with a database query in each tool handler
- **Change the model**: Set `MODEL_NAME` environment variable or edit the default
