#!/usr/bin/env python3
"""
Expense Reporting Assistant Chatbot
====================================

A single-file, self-contained chatbot that helps employees:
  - Query company expense policies
  - Submit new expense entries (with policy validation)
  - View and delete existing expenses
  - Calculate reimbursements with policy-capped rules
  - Get department-level expense summaries

Built with the OpenAI Python SDK:
  - Chat completion with function calling (tools)
  - Parallel tool calls (batching)
  - Conversation message management (bounded history)
  - Few-shot examples embedded in the system prompt
  - Chain-of-thought reasoning in tool outputs

Usage:
    python expense_chatbot.py              # interactive CLI
    python expense_chatbot.py --demo       # run test cases, save logs

Environment Variables:
    OPENAI_API_KEY           Standard OpenAI API key
    AZURE_OPENAI_API_KEY     Azure OpenAI API key (preferred if both set)
    AZURE_OPENAI_ENDPOINT    Azure endpoint (required for Azure mode)
    MODEL_NAME               Model to use (default: gpt-4o-mini)
    API_VERSION              Azure API version (default: 2024-07-01-preview)
"""

# ==============================================================================
# 1. Imports & Standard Library
# ==============================================================================

import argparse
import json
import os
import sys
import copy
from datetime import datetime, date
from typing import Optional

try:
    from openai import AzureOpenAI, OpenAI
except ImportError:
    print("ERROR: The 'openai' package is required.")
    print("Install it with: pip install openai")
    sys.exit(1)


# ==============================================================================
# 2. Configuration
# ==============================================================================

MODEL_NAME = os.getenv("MODEL_NAME", "gpt-4o-mini")
MAX_MESSAGE_HISTORY = 30  # bounded context window
MAX_FUNCTION_CALL_ITERATIONS = 5  # safety limit per user turn
LOG_FILENAME = "conversation_logs.json"

# ANSI colour helpers (auto-disable on Windows / non-tty)
_USE_COLOR = hasattr(sys.stdout, "isatty") and sys.stdout.isatty()

def _green(text: str) -> str:
    return f"\033[92m{text}\033[0m" if _USE_COLOR else text

def _blue(text: str) -> str:
    return f"\033[94m{text}\033[0m" if _USE_COLOR else text

def _yellow(text: str) -> str:
    return f"\033[93m{text}\033[0m" if _USE_COLOR else text

def _bold(text: str) -> str:
    return f"\033[1m{text}\033[0m" if _USE_COLOR else text

def _dim(text: str) -> str:
    return f"\033[2m{text}\033[0m" if _USE_COLOR else text


# ==============================================================================
# 3. Mock Data
# ==============================================================================

# --- Expense Policy FAQs ---
EXPENSE_POLICY_FAQS = [
    {
        "topic": "receipt",
        "rule": "Receipts are required for all expenses above $25. Expenses of $25 or less do not need a receipt attached.",
    },
    {
        "topic": "travel",
        "rule": "Travel expenses (flights, trains, hotels) must be pre-approved by your manager before booking. Unapproved travel expenses will be rejected.",
    },
    {
        "topic": "meal",
        "rule": "Meal expenses are reimbursed up to $50 per day. Any amount exceeding $50 in a single day is not reimbursable.",
    },
    {
        "topic": "taxi",
        "rule": "Taxi and ride-share expenses require a detailed trip log including pickup location, drop-off location, and business purpose.",
    },
    {
        "topic": "lodging",
        "rule": "Lodging expenses are reimbursed up to $200 per night. Expenses above $200/night require VP-level approval.",
    },
    {
        "topic": "entertainment",
        "rule": "Client entertainment expenses are reimbursed up to $75 per event and require the client's name and company as documentation.",
    },
    {
        "topic": "submission_deadline",
        "rule": "All expense reports must be submitted by the 5th business day of the month following the expense date. Late submissions may be delayed to the next reimbursement cycle.",
    },
    {
        "topic": "currency",
        "rule": "International expenses must be reported in USD. Use the exchange rate on the date of the expense.",
    },
]

# --- Pre-seeded Expense Reports ---
MOCK_EXPENSE_REPORTS = [
    {"employee_id": "E123", "date": "2025-05-01", "category": "Meals",
     "amount": 45.00, "description": "Client lunch at Downtown Bistro"},
    {"employee_id": "E123", "date": "2025-05-02", "category": "Taxi",
     "amount": 30.50, "description": "Airport to hotel — client visit"},
    {"employee_id": "E456", "date": "2025-05-01", "category": "Travel",
     "amount": 1200.00, "description": "Flight to NYC for conference"},
    {"employee_id": "E456", "date": "2025-05-03", "category": "Lodging",
     "amount": 180.00, "description": "Hotel in NYC — 2 nights"},
    {"employee_id": "E789", "date": "2025-05-02", "category": "Meals",
     "amount": 62.00, "description": "Team dinner after project milestone"},
    {"employee_id": "E789", "date": "2025-05-04", "category": "Entertainment",
     "amount": 55.00, "description": "Client coffee meeting — Acme Corp"},
]

# --- Employee Directory ---
EMPLOYEE_DIRECTORY = {
    "E123": {"name": "Alice Johnson",   "department": "Engineering"},
    "E456": {"name": "Bob Smith",       "department": "Marketing"},
    "E789": {"name": "Carol Williams",  "department": "Sales"},
}

# --- Policy Caps (used by calculation engine) ---
CATEGORY_CAPS = {
    "meals":        50.0,
    "lodging":     200.0,
    "entertainment": 75.0,
}
FULLY_REIMBURSED = ["taxi", "travel"]


# ==============================================================================
# 4. Policy Engine
# ==============================================================================

def _policy_warnings(entry: dict) -> list[str]:
    """Return a list of policy warnings for a single expense entry."""
    warnings = []
    cat = entry.get("category", "").lower()
    amount = entry.get("amount", 0)

    if amount > 25:
        warnings.append(f"Receipt required (amount ${amount:.2f} > $25).")
    if cat == "travel":
        warnings.append("Travel must be pre-approved by your manager before booking.")
    if cat == "taxi":
        warnings.append("Taxi requires a detailed trip log (pickup, drop-off, business purpose).")
    if cat in CATEGORY_CAPS:
        cap = CATEGORY_CAPS[cat]
        if amount > cap:
            warnings.append(
                f"Per-diem cap for {cat} is ${cap:.2f}; excess of ${amount - cap:.2f} will not be reimbursed."
            )
    if cat == "entertainment":
        warnings.append("Client entertainment requires the client's name and company.")
    return warnings


def _calculate_breakdown(expenses: list[dict]) -> dict:
    """
    Calculate reimbursement with step-by-step per-line-item breakdown.
    Returns { "items": [ {...}, ... ], "total": float }.
    Each item has: category, amount, cap_note, reimbursed.
    """
    items = []
    total = 0.0
    for e in expenses:
        cat = e.get("category", "unknown").lower()
        amount = float(e.get("amount", 0))

        if cat in CATEGORY_CAPS:
            cap = CATEGORY_CAPS[cat]
            reimbursed = min(amount, cap)
            cap_note = f"Cap: ${cap:.2f}/day" if cat == "meals" else f"Cap: ${cap:.2f}/night"
        elif cat in FULLY_REIMBURSED:
            reimbursed = amount
            cap_note = "Fully reimbursed"
        else:
            reimbursed = 0.0
            cap_note = "Category not recognized — $0 reimbursed"

        items.append({
            "category": e.get("category", "unknown"),
            "amount": amount,
            "reimbursed": reimbursed,
            "cap_note": cap_note,
        })
        total += reimbursed

    return {"items": items, "total": round(total, 2)}


# ==============================================================================
# 5. Output Formatters
# ==============================================================================

def _format_table(headers: list[str], rows: list[list[str]], col_widths: Optional[list[int]] = None) -> str:
    """Render a simple ASCII table."""
    if col_widths is None:
        col_widths = [max(len(str(r[i])) for r in [headers] + rows) for i in range(len(headers))]
    # header line
    hdr = " | ".join(str(h).ljust(w) for h, w in zip(headers, col_widths))
    sep = "-+-".join("-" * w for w in col_widths)
    body = "\n".join(" | ".join(str(c).ljust(w) for c, w in zip(row, col_widths)) for row in rows)
    return f"{hdr}\n{sep}\n{body}"


def format_expense_table(expenses: list[dict], title: str = "Expense Report") -> str:
    """Format a list of expense dicts as an aligned table."""
    headers = ["#", "Date", "Category", "Amount", "Description"]
    rows = []
    for i, e in enumerate(expenses, 1):
        rows.append([
            str(i),
            e.get("date", ""),
            e.get("category", ""),
            f"${e.get('amount', 0):.2f}",
            e.get("description", ""),
        ])
    lines = [f"\n{_bold(title)}\n"]
    lines.append(_format_table(headers, rows))
    return "\n".join(lines)


def format_policy_bullets(policies: list[dict]) -> str:
    """Format policy FAQ matches as bullet points."""
    if not policies:
        return "  No matching policy found. Try a different keyword."
    lines = []
    for p in policies:
        lines.append(f"  • **{p['topic'].title()}**: {p['rule']}")
    return "\n".join(lines)


def format_reimbursement(result: dict) -> str:
    """
    Format the reimbursement breakdown with chain-of-thought style
    per-line-item reasoning.
    """
    lines = ["\n" + _bold("Reimbursement Calculation")]
    lines.append("")
    for item in result["items"]:
        lines.append(
            f"  • {item['category']}: ${item['amount']:.2f} → "
            f"reimbursed ${item['reimbursed']:.2f} ({item['cap_note']})"
        )
    lines.append("")
    lines.append(f"  {_bold('Total Reimbursement: $' + f'{result['total']:.2f}')}")
    return "\n".join(lines)


def format_receipt(entry: dict, warnings: list[str]) -> str:
    """Format a newly submitted expense as a receipt-like block."""
    lines = [
        "\n" + _bold("── Expense Submitted ──"),
        f"  Employee   : {entry.get('employee_id', 'N/A')}",
        f"  Date       : {entry.get('date', 'N/A')}",
        f"  Category   : {entry.get('category', 'N/A')}",
        f"  Amount     : ${entry.get('amount', 0):.2f}",
        f"  Description: {entry.get('description', 'N/A')}",
        "",
    ]
    if warnings:
        lines.append(f"  {_yellow('⚠ Policy Warnings:')}")
        for w in warnings:
            lines.append(f"    • {w}")
    else:
        lines.append(f"  {_green('✓ No policy warnings.')}")
    lines.append("")
    return "\n".join(lines)


def format_department_summary(dept: str, employees: dict, total: float) -> str:
    """Format a department summary with per-employee breakdown."""
    lines = [
        f"\n{_bold(f'Department Summary: {dept}')}",
        "",
    ]
    headers = ["Employee ID", "Name", "Expenses", "Total"]
    rows = []
    for emp_id, info in employees.items():
        rows.append([
            emp_id,
            info["name"],
            str(info["expense_count"]),
            f"${info['expense_total']:.2f}",
        ])
    lines.append(_format_table(headers, rows))
    lines.append(f"\n  {_bold(f'Department Total: ${total:.2f}')}\n")
    return "\n".join(lines)


def format_tool_call_log(func_name: str, args: dict) -> str:
    """Format a tool-call invocation for display."""
    return _dim(f"  [tool] {func_name}({json.dumps(args, default=str)})")


def format_tool_result(func_name: str, result_text: str) -> str:
    """Format a tool result for display."""
    truncated = result_text if len(result_text) < 200 else result_text[:197] + "..."
    return _dim(f"  [result] {func_name}: {truncated}")


# ==============================================================================
# 6. Tool Definitions  (OpenAI `tools` JSON schema)
# ==============================================================================

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "query_expense_policy",
            "description": "Search the company expense policy by topic keyword. Use this when the user asks about rules, limits, requirements, or deadlines.",
            "parameters": {
                "type": "object",
                "properties": {
                    "topic": {
                        "type": "string",
                        "description": "Keyword or topic to search for, e.g. 'meal', 'travel', 'receipt', 'lodging', 'taxi', 'deadline', 'entertainment'.",
                    }
                },
                "required": ["topic"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "calculate_reimbursement",
            "description": "Calculate total reimbursement amount from a list of expenses, applying policy caps per category. Returns a per-line-item breakdown and total.",
            "parameters": {
                "type": "object",
                "properties": {
                    "expenses": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "category": {"type": "string"},
                                "amount":   {"type": "number"},
                                "date":     {"type": "string"},
                            },
                            "required": ["category", "amount"],
                        },
                    }
                },
                "required": ["expenses"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_employee_expenses",
            "description": "Retrieve all recorded expense entries for a specific employee by their employee ID.",
            "parameters": {
                "type": "object",
                "properties": {
                    "employee_id": {
                        "type": "string",
                        "description": "Employee ID, e.g. 'E123', 'E456', 'E789'.",
                    }
                },
                "required": ["employee_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "submit_expense",
            "description": "Submit a new expense entry. Validates the entry against company policy and returns any warnings.",
            "parameters": {
                "type": "object",
                "properties": {
                    "employee_id": {
                        "type": "string",
                        "description": "Employee ID, e.g. 'E123'.",
                    },
                    "date": {
                        "type": "string",
                        "description": "Date of the expense in YYYY-MM-DD format.",
                    },
                    "category": {
                        "type": "string",
                        "description": "Expense category: Meals, Taxi, Travel, Lodging, or Entertainment.",
                    },
                    "amount": {
                        "type": "number",
                        "description": "Expense amount in USD.",
                    },
                    "description": {
                        "type": "string",
                        "description": "Brief description of the expense.",
                    },
                },
                "required": ["employee_id", "date", "category", "amount"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "delete_expense",
            "description": "Delete an existing expense entry by its 1-based index in the employee's expense list.",
            "parameters": {
                "type": "object",
                "properties": {
                    "employee_id": {
                        "type": "string",
                        "description": "Employee ID, e.g. 'E123'.",
                    },
                    "expense_index": {
                        "type": "integer",
                        "description": "1-based index of the expense to delete (from the employee's expense list).",
                    },
                },
                "required": ["employee_id", "expense_index"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_department_summary",
            "description": "Get an aggregated expense summary for a specific department, including per-employee breakdowns.",
            "parameters": {
                "type": "object",
                "properties": {
                    "department": {
                        "type": "string",
                        "description": "Department name, e.g. 'Engineering', 'Marketing', 'Sales'.",
                    }
                },
                "required": ["department"],
            },
        },
    },
]


# ==============================================================================
# 7. Tool Handlers
# ==============================================================================

def _handle_tool_call(func_name: str, func_args: dict) -> str:
    """
    Dispatch a function call to the appropriate handler.
    Returns a JSON-serialisable string (the tool result).
    """

    # --- query_expense_policy ---
    if func_name == "query_expense_policy":
        topic = func_args.get("topic", "").lower()
        matches = [p for p in EXPENSE_POLICY_FAQS if topic in p["topic"].lower() or topic in p["rule"].lower()]
        if matches:
            # Chain-of-thought: explain matching process
            cot = (
                f"I searched the expense policy database for the keyword '{topic}'. "
                f"Found {len(matches)} matching rule(s):\n"
            )
            for m in matches:
                cot += f"  - [{m['topic']}] {m['rule']}\n"
            return json.dumps({
                "type": "policy_query",
                "topic": topic,
                "reasoning": cot.strip(),
                "policies": matches,
            })
        return json.dumps({
            "type": "policy_query",
            "topic": topic,
            "reasoning": f"I searched for '{topic}' but found no exact match. The available policy topics are: {', '.join(p['topic'] for p in EXPENSE_POLICY_FAQS)}.",
            "policies": [],
        })

    # --- calculate_reimbursement ---
    if func_name == "calculate_reimbursement":
        expenses = func_args.get("expenses", [])
        result = _calculate_breakdown(expenses)
        # Chain-of-thought: step-by-step reasoning
        cot_parts = []
        for item in result["items"]:
            cat = item["category"].lower()
            amount = item["amount"]
            reimbursed = item["reimbursed"]
            if cat in CATEGORY_CAPS:
                cap = CATEGORY_CAPS[cat]
                cot_parts.append(
                    f"  {item['category']}: ${amount:.2f}. "
                    f"Policy cap is ${cap:.2f}. "
                    f"Reimbursed = min(${amount:.2f}, ${cap:.2f}) = ${reimbursed:.2f}."
                )
            elif cat in FULLY_REIMBURSED:
                cot_parts.append(
                    f"  {item['category']}: ${amount:.2f}. Fully reimbursed per policy = ${reimbursed:.2f}."
                )
            else:
                cot_parts.append(
                    f"  {item['category']}: ${amount:.2f}. Category not in reimbursable list. $0."
                )
        cot = (
            "Step-by-step reimbursement calculation:\n"
            + "\n".join(cot_parts)
            + f"\nTotal = ${result['total']:.2f}."
        )
        return json.dumps({
            "type": "reimbursement",
            "reasoning": cot,
            "items": result["items"],
            "total": result["total"],
        })

    # --- get_employee_expenses ---
    if func_name == "get_employee_expenses":
        emp_id = func_args.get("employee_id", "")
        if emp_id not in EMPLOYEE_DIRECTORY:
            known = ", ".join(EMPLOYEE_DIRECTORY.keys())
            return json.dumps({
                "type": "employee_expenses",
                "error": f"Employee ID '{emp_id}' not found. Known IDs: {known}.",
                "expenses": [],
            })
        expenses = [e for e in MOCK_EXPENSE_REPORTS if e["employee_id"] == emp_id]
        return json.dumps({
            "type": "employee_expenses",
            "employee_id": emp_id,
            "employee_name": EMPLOYEE_DIRECTORY[emp_id]["name"],
            "expense_count": len(expenses),
            "expenses": expenses,
        })

    # --- submit_expense ---
    if func_name == "submit_expense":
        emp_id = func_args.get("employee_id", "")
        date_str = func_args.get("date", "")
        category = func_args.get("category", "")
        amount = func_args.get("amount", 0)
        description = func_args.get("description", "")

        # Validate required fields
        if not emp_id or not date_str or not category or amount is None:
            missing = []
            if not emp_id: missing.append("employee_id")
            if not date_str: missing.append("date")
            if not category: missing.append("category")
            if amount is None: missing.append("amount")
            return json.dumps({
                "type": "submit_expense",
                "error": f"Missing required fields: {', '.join(missing)}. Please provide all required information before submitting.",
                "success": False,
            })

        if emp_id not in EMPLOYEE_DIRECTORY:
            return json.dumps({
                "type": "submit_expense",
                "error": f"Employee ID '{emp_id}' not found. Please verify the ID.",
                "success": False,
            })

        entry = {
            "employee_id": emp_id,
            "date": date_str,
            "category": category,
            "amount": amount,
            "description": description,
        }
        warnings = _policy_warnings(entry)
        MOCK_EXPENSE_REPORTS.append(entry)
        return json.dumps({
            "type": "submit_expense",
            "success": True,
            "entry": entry,
            "warnings": warnings,
        })

    # --- delete_expense ---
    if func_name == "delete_expense":
        emp_id = func_args.get("employee_id", "")
        index = func_args.get("expense_index", 0)
        emp_expenses = [e for e in MOCK_EXPENSE_REPORTS if e["employee_id"] == emp_id]
        if emp_id not in EMPLOYEE_DIRECTORY:
            return json.dumps({
                "type": "delete_expense",
                "error": f"Employee ID '{emp_id}' not found.",
                "success": False,
            })
        if index < 1 or index > len(emp_expenses):
            return json.dumps({
                "type": "delete_expense",
                "error": f"Invalid index {index}. Employee has {len(emp_expenses)} expense(s) (index 1–{len(emp_expenses)}).",
                "success": False,
            })
        removed = emp_expenses[index - 1]
        MOCK_EXPENSE_REPORTS.remove(removed)
        return json.dumps({
            "type": "delete_expense",
            "success": True,
            "removed": removed,
            "remaining_count": len([e for e in MOCK_EXPENSE_REPORTS if e["employee_id"] == emp_id]),
        })

    # --- get_department_summary ---
    if func_name == "get_department_summary":
        dept = func_args.get("department", "").title()
        dept_employees = {
            eid: info for eid, info in EMPLOYEE_DIRECTORY.items()
            if info["department"].lower() == dept.lower()
        }
        if not dept_employees:
            known_depts = sorted(set(v["department"] for v in EMPLOYEE_DIRECTORY.values()))
            return json.dumps({
                "type": "department_summary",
                "error": f"Department '{dept}' not found. Known departments: {', '.join(known_depts)}.",
                "department": dept,
                "employees": {},
                "total": 0,
            })
        result_employees = {}
        grand_total = 0.0
        for eid, info in dept_employees.items():
            expenses = [e for e in MOCK_EXPENSE_REPORTS if e["employee_id"] == eid]
            emp_total = sum(e["amount"] for e in expenses)
            result_employees[eid] = {
                "name": info["name"],
                "expense_count": len(expenses),
                "expense_total": emp_total,
                "expenses": expenses,
            }
            grand_total += emp_total
        return json.dumps({
            "type": "department_summary",
            "department": dept,
            "employees": result_employees,
            "total": round(grand_total, 2),
        })

    return json.dumps({"error": f"Unknown function: {func_name}"})


# ==============================================================================
# 8. System Prompt (with Few-Shot Examples and Chain-of-Thought Instructions)
# ==============================================================================

SYSTEM_PROMPT = """\
You are the **Expense Reporting Assistant**, an AI-powered chatbot that helps employees manage expense reports, understand company policies, and calculate reimbursements.

## Your Capabilities
You can:
1. Answer questions about company expense policies (meal limits, receipt rules, travel approval, etc.)
2. Look up an employee's existing expenses
3. Submit new expense entries with policy validation
4. Delete expense entries
5. Calculate reimbursement amounts with step-by-step policy rule application
6. Provide department-level expense summaries

## Company Expense Policy Rules
- Receipts are required for all expenses above $25.
- Travel expenses must be pre-approved by manager before booking.
- Meal expenses are reimbursed up to $50 per day.
- Taxi expenses require detailed trip logs (pickup, drop-off, business purpose).
- Lodging expenses are reimbursed up to $200 per night.
- Client entertainment is reimbursed up to $75 per event (client name + company required).
- Expense reports must be submitted by the 5th business day of the following month.
- International expenses must be reported in USD.

## How to Reason (Chain-of-Thought)
Before answering, ALWAYS reason through the relevant policy rules step by step:
- For policy queries: identify which rules match the user's question, then explain each matching rule.
- For reimbursement: for each expense line item, state the category, the amount, the applicable cap or rule, and the reimbursed amount before computing the total.
- For submissions: check each policy rule against the entry and list any warnings.

## Few-Shot Examples

### Example 1 — Policy Query
User: "What's the daily meal limit?"
Assistant: [calls query_expense_policy(topic="meal")]
Tool result: Meal expenses are reimbursed up to $50 per day.
Assistant: "The daily meal expense limit is **$50 per day**. Any amount exceeding $50 in a single day won't be reimbursed. If you have multiple meal expenses on the same day, they're combined and capped at $50 total for that day."

### Example 2 — Submit Expense
User: "I want to submit a $45 meal expense for E123 on 2025-05-06. It was a team lunch."
Assistant: [calls submit_expense(employee_id="E123", date="2025-05-06", category="Meals", amount=45, description="Team lunch")]
Tool result: success=True, warnings=["Receipt required (amount $45.00 > $25)."]
Assistant: "✅ Expense submitted successfully!

  ── Expense Submitted ──
  Employee   : E123
  Date       : 2025-05-06
  Category   : Meals
  Amount     : $45.00
  Description: Team lunch

  ⚠ Policy Warning: Receipt required (amount $45.00 > $25). Please attach the receipt to your report."

### Example 3 — Reimbursement Calculation
User: "Calculate my reimbursement for E123."
Assistant: [calls get_employee_expenses(employee_id="E123")]
Tool result: 2 expenses returned
Assistant: [calls calculate_reimbursement with those expenses]
Tool result: items=[{Meals: $45, reimbursed $45}, {Taxi: $30.50, reimbursed $30.50}], total=$75.50
Assistant: "Here's your reimbursement breakdown for Alice Johnson (E123):

  Reimbursement Calculation

  • Meals: $45.00 → reimbursed $45.00 (Cap: $50.00/day)
  • Taxi: $30.50 → reimbursed $30.50 (Fully reimbursed)

  Total Reimbursement: $75.50"

### Example 4 — Ambiguous Input
User: "I spent money on food yesterday."
Assistant: "I'd be happy to help you submit that expense! I need a few more details:
  1. What's your employee ID?
  2. How much did you spend?
  3. What was a brief description (e.g., client lunch, team dinner)?

Once you provide these, I'll submit it and check it against policy rules."

## Important Behavior Rules
- If the user's request is ambiguous or missing required information, ask clarifying questions BEFORE calling any tool.
- Always present reimbursement calculations as a step-by-step breakdown per line item.
- When policy warnings arise, highlight them clearly and explain what the user should do.
- Keep responses concise, friendly, and well-formatted with bullet points and tables where helpful.
- Available employee IDs: E123 (Alice Johnson, Engineering), E456 (Bob Smith, Marketing), E789 (Carol Williams, Sales).
"""


# ==============================================================================
# 9. Client Factory
# ==============================================================================

def create_client():
    """Create an OpenAI or AzureOpenAI client from environment variables."""
    azure_key = os.getenv("AZURE_OPENAI_API_KEY")
    azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")

    if azure_key and azure_endpoint:
        api_version = os.getenv("API_VERSION", "2024-07-01-preview")
        return AzureOpenAI(
            api_key=azure_key,
            azure_endpoint=azure_endpoint,
            api_version=api_version,
        )
    else:
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            print(_yellow("WARNING: No API key found."))
            print("  Set OPENAI_API_KEY or (AZURE_OPENAI_API_KEY + AZURE_OPENAI_ENDPOINT).")
            print("  The chatbot will run in demo-only mode (no live API calls).")
        return OpenAI(api_key=api_key or "demo-key")


# ==============================================================================
# 10. Conversation Manager
# ==============================================================================

class ConversationManager:
    """Manages conversation history and tool-call roundtrips."""

    def __init__(self, client, max_history: int = MAX_MESSAGE_HISTORY):
        self.client = client
        self.max_history = max_history
        self.messages: list[dict] = [
            {"role": "system", "content": SYSTEM_PROMPT},
        ]
        # Full log for saving later
        self.log: list[dict] = []

    def add_user_message(self, text: str):
        self.messages.append({"role": "user", "content": text})

    def _trim_history(self):
        """Keep system message + most recent user/assistant pairs."""
        if len(self.messages) <= self.max_history:
            return
        # Keep system + last (max_history - 1) messages
        self.messages = [self.messages[0]] + self.messages[-(self.max_history - 1):]

    def _execute_tool_calls(self, tool_calls: list) -> list[dict]:
        """Execute tool calls (supports parallel/batched calls) and return results."""
        results = []
        for tc in tool_calls:
            func_name = tc.function.name
            func_args = json.loads(tc.function.arguments)
            print(format_tool_call_log(func_name, func_args))
            raw_result = _handle_tool_call(func_name, func_args)
            result_obj = json.loads(raw_result)

            # Print human-readable output for known types
            if result_obj.get("type") == "reimbursement":
                print(format_reimbursement(result_obj))
            elif result_obj.get("type") == "submit_expense" and result_obj.get("success"):
                print(format_receipt(result_obj["entry"], result_obj.get("warnings", [])))
            elif result_obj.get("type") == "department_summary" and result_obj.get("employees"):
                print(format_department_summary(
                    result_obj["department"], result_obj["employees"], result_obj["total"]
                ))

            print(format_tool_result(func_name, raw_result))
            results.append({
                "role": "tool",
                "tool_call_id": tc.id,
                "content": raw_result,
            })
        return results

    def get_response(self, user_input: str) -> str:
        """
        Send user input, handle function-call roundtrips, return assistant text.
        Supports parallel tool calls (batching) in a single turn.
        """
        self.add_user_message(user_input)
        self._trim_history()

        final_content = ""

        for iteration in range(MAX_FUNCTION_CALL_ITERATIONS):
            try:
                response = self.client.chat.completions.create(
                    model=MODEL_NAME,
                    messages=self.messages,
                    tools=TOOLS,
                    parallel_tool_calls=True,
                    temperature=0.1,
                )
            except Exception as exc:
                err_msg = f"API error: {exc}"
                # In demo mode without real API, return a helpful message
                if not os.getenv("OPENAI_API_KEY") and not os.getenv("AZURE_OPENAI_API_KEY"):
                    return (
                        _yellow("[Demo Mode — no API key configured]\n")
                        + "To run with a live model, set OPENAI_API_KEY or "
                        "AZURE_OPENAI_API_KEY + AZURE_OPENAI_ENDPOINT.\n\n"
                        f"You said: {user_input}\n\n"
                        "The chatbot would call the appropriate tool(s) and respond "
                        "based on company expense policies."
                    )
                raise RuntimeError(err_msg) from exc

            choice = response.choices[0]
            msg = choice.message

            # --- Function call(s) ---
            if msg.tool_calls:
                self.messages.append({
                    "role": "assistant",
                    "content": msg.content or None,
                    "tool_calls": [
                        {
                            "id": tc.id,
                            "type": "function",
                            "function": {
                                "name": tc.function.name,
                                "arguments": tc.function.arguments,
                            },
                        }
                        for tc in msg.tool_calls
                    ],
                })
                # Execute (potentially parallel) tool calls
                tool_results = self._execute_tool_calls(msg.tool_calls)
                self.messages.extend(tool_results)
                # Loop back — model will generate final text response
                continue

            # --- Text response ---
            final_content = msg.content or ""
            self.messages.append({"role": "assistant", "content": final_content})
            break
        else:
            final_content = _yellow("(Max function-call iterations reached. The response may be incomplete.)")

        # Log this exchange
        self.log.append({
            "user_input": user_input,
            "assistant_response": final_content,
            "messages_snapshot": copy.deepcopy(self.messages[-6:]),  # last 6 for context
            "timestamp": datetime.now().isoformat(),
        })
        return final_content

    def get_log(self) -> list[dict]:
        return copy.deepcopy(self.log)

    def reset(self):
        self.messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        self.log = []


# ==============================================================================
# 11. Expense Chatbot (Main Class)
# ==============================================================================

class ExpenseChatbot:
    """High-level chatbot that wraps the conversation manager and CLI."""

    BANNER = (
        "\n"
        + "╔══════════════════════════════════════════════════════════╗\n"
        + "║     Expense Reporting Assistant — Powered by OpenAI      ║\n"
        + "╠══════════════════════════════════════════════════════════╣\n"
        + "║  Type your message, or /help for commands.               ║\n"
        + "╚══════════════════════════════════════════════════════════╝\n"
    )

    def __init__(self):
        self.client = create_client()
        self.conv = ConversationManager(self.client)

    def run_interactive(self):
        """Run the interactive REPL."""
        print(_bold(self.BANNER))
        print(_dim("Session started. Type /help for available commands.\n"))

        while True:
            try:
                user_input = input(_blue("You: ")).strip()
            except (EOFError, KeyboardInterrupt):
                print("\n" + _bold("Goodbye!"))
                break

            if not user_input:
                continue

            # --- CLI commands ---
            if user_input.startswith("/"):
                handled = self._handle_command(user_input)
                if handled:
                    continue

            # --- Chat with model ---
            try:
                response = self.conv.get_response(user_input)
                print(f"\n{_bold('Assistant:')}\n{response}\n")
            except Exception as exc:
                print(f"\n{_yellow('Error:')} {exc}\n")

    def run_demo(self):
        """Run the predefined test cases and save conversation logs."""
        print(_bold("=== Expense Reporting Assistant — Demo Mode ===\n"))
        print(f"Running test cases TC_01 through TC_04...\n")

        test_cases = [
            {
                "id": "TC_01",
                "description": "Ask chatbot about expense policies → accurate, policy-based reply",
                "inputs": [
                    "What is the meal expense limit?",
                    "Do I need a receipt for a $20 coffee?",
                ],
            },
            {
                "id": "TC_02",
                "description": "Submit sample expense entries and trigger reimbursement calc",
                "inputs": [
                    "Submit a $35 meal expense for E123 on 2025-05-07. It was a working lunch with a colleague.",
                    "Now calculate my total reimbursement for E123.",
                ],
            },
            {
                "id": "TC_03",
                "description": "Handle ambiguous or incomplete expense details gracefully",
                "inputs": [
                    "I spent some money on food yesterday.",
                ],
            },
            {
                "id": "TC_04",
                "description": "Multi-turn conversation remembers previous inputs and context",
                "inputs": [
                    "Show me all expenses for E456.",
                    "Delete the first expense for E456.",
                    "Now show me E456's expenses again to confirm it was deleted.",
                ],
            },
        ]

        for tc in test_cases:
            print(f"\n{'=' * 60}")
            print(f"{_bold(f'  {tc["id"]}: {tc["description"]}')}\n")
            print(_dim(f"  Test: {tc['description']}\n"))

            for user_msg in tc["inputs"]:
                print(f"  {_blue('User:')} {user_msg}")
                try:
                    response = self.conv.get_response(user_msg)
                    print(f"  {_bold('Assistant:')} {response}")
                except Exception as exc:
                    print(f"  {_yellow('Error:')} {exc}")
                print()

        # Save conversation logs
        log_data = {
            "demo_timestamp": datetime.now().isoformat(),
            "model": MODEL_NAME,
            "test_cases": [
                {
                    "id": tc["id"],
                    "description": tc["description"],
                    "inputs": tc["inputs"],
                }
                for tc in test_cases
            ],
            "conversation_log": self.conv.get_log(),
        }
        with open(LOG_FILENAME, "w") as f:
            json.dump(log_data, f, indent=2, default=str)
        print(_bold(f"\n✅ Demo complete. Conversation logs saved to {_green(LOG_FILENAME)}"))

    def _handle_command(self, cmd: str) -> bool:
        """Handle /-prefixed CLI commands. Returns True if handled."""
        parts = cmd.split(maxsplit=1)
        command = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""

        if command == "/help":
            print("""\
Available Commands:
  /help        Show this help message
  /clear       Clear conversation history
  /log         Save conversation log to file
  /employees   List known employees
  /expenses    Show all current expenses
  /policy      Show all expense policies
  /quit, /exit Exit the chatbot
""")
            return True

        if command == "/clear":
            self.conv.reset()
            print(_green("Conversation history cleared."))
            return True

        if command == "/log":
            filename = arg.strip() or LOG_FILENAME
            log_data = {
                "timestamp": datetime.now().isoformat(),
                "model": MODEL_NAME,
                "conversation_log": self.conv.get_log(),
            }
            with open(filename, "w") as f:
                json.dump(log_data, f, indent=2, default=str)
            print(_green(f"Conversation log saved to {filename}."))
            return True

        if command == "/employees":
            lines = ["\n" + _bold("Employee Directory")]
            for eid, info in EMPLOYEE_DIRECTORY.items():
                lines.append(f"  {eid}: {info['name']} — {info['department']}")
            print("\n".join(lines) + "\n")
            return True

        if command == "/expenses":
            if MOCK_EXPENSE_REPORTS:
                print(format_expense_table(MOCK_EXPENSE_REPORTS, "All Expense Entries"))
            else:
                print("  No expenses recorded.")
            print()
            return True

        if command == "/policy":
            print("\n" + _bold("Company Expense Policies"))
            for p in EXPENSE_POLICY_FAQS:
                print(f"  • [{p['topic'].title()}] {p['rule']}")
            print()
            return True

        if command in ("/quit", "/exit"):
            print(_bold("Goodbye!"))
            sys.exit(0)
            return True

        print(_yellow(f"Unknown command: {command}. Type /help for available commands."))
        return True


# ==============================================================================
# 12. Entry Point
# ==============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Expense Reporting Assistant Chatbot",
    )
    parser.add_argument(
        "--demo",
        action="store_true",
        help="Run predefined test cases (TC_01–TC_04) and save conversation logs.",
    )
    args = parser.parse_args()

    bot = ExpenseChatbot()

    if args.demo:
        bot.run_demo()
    else:
        bot.run_interactive()


if __name__ == "__main__":
    main()
