# Expense Reporting Assistant Chatbot — Complete Plan

## Source Document

`docs/Workshop_2_Artifact/Workshop_2_Artifact.md` — Workshop 2: Building Real-World Chatbot Systems Using Azure OpenAI API

---

## 1. Plan Overview

Build an **Expense Reporting Assistant Chatbot** — a single self-contained Python CLI script that uses the OpenAI chat completion API with function calling to help employees submit expense reports, look up policies, calculate reimbursements, and manage their expense entries through natural, multi-turn conversation.

---

## 2. Deliverable 1: `expense_chatbot.py`

A single Python script containing everything — mock data, tool definitions, OpenAI integration, and CLI interface.

### 2.1 Structure

| Section | Purpose |
|---|---|
| **Mock Data** | Expense policy FAQs, sample expense reports, employee directory, department budget info |
| **Policy Engine** | Reimbursement calculation logic with policy constraints (meal cap $50/day, receipt threshold $25, travel pre-approval, taxi trip logs, lodging cap $200/night) |
| **Tool Definitions** | 6 OpenAI function-calling tools (JSON schema) |
| **Tool Handlers** | Pure-Python functions that execute each tool against mock data |
| **Conversation Manager** | Maintains message history, injects few-shot examples, applies chain-of-thought system prompt, handles function call roundtrips |
| **CLI Interface** | Interactive REPL with color-coded output, typed commands, session save/load, and test-case runner |

### 2.2 The 6 Function-Calling Tools

| Function | Description | Parameters |
|---|---|---|
| `query_expense_policy` | Search policy FAQs by keyword | `topic: string` |
| `calculate_reimbursement` | Calculate reimbursement with policy rules applied | `expenses: array[{category, amount, date}]` |
| `get_employee_expenses` | Retrieve all expenses for a given employee | `employee_id: string` |
| `submit_expense` | Add a new expense entry with policy validation | `employee_id, date, category, amount, description: string` |
| `delete_expense` | Remove an expense entry by index | `employee_id, expense_index: string/number` |
| `get_department_summary` | Aggregate expenses by department | `department: string` |

### 2.3 Key Design Decisions

1. **Function calling (not plain prompting)** — Structured tool calls let the model reliably retrieve data and perform calculations, reducing hallucination.
2. **Few-shot examples in system prompt** — The system message embeds example dialogues (policy Q&A, reimbursement request) so the model learns the expected response style.
3. **Chain-of-thought reasoning** — The system prompt instructs the model to walk through policy rules step-by-step before answering complex queries.
4. **Message window management** — Keeps a bounded conversation history (configurable, default 20 messages) to stay within context limits while preserving recent context.
5. **Policy validation on submit** — `submit_expense` checks policy rules (receipt needed? over daily limit? pre-approval required?) and returns warnings alongside the confirmation.
6. **Dual mode** — Works in interactive mode (REPL) or demo mode (`--demo`) that runs the 4 test cases from the document (TC_01 through TC_04) non-interactively.
7. **Session persistence** — Optionally save/load conversation logs to JSON for review.
8. **Graceful error handling** — API failures, missing employee IDs, and ambiguous inputs produce helpful recovery messages instead of crashes.

### 2.4 Mock Data

```
expense_policy_faqs:    4+ policy rules (receipts, travel approval, meal cap, taxi logs, lodging cap)
mock_expense_reports:   3+ pre-seeded expense entries across 2 employees
employee_directory:     3 employees with ID → name + department mapping
```

### 2.5 Configuration

Reads from environment variables (supports both Azure OpenAI and standard OpenAI):

- `OPENAI_API_KEY` / `AZURE_OPENAI_API_KEY`
- `AZURE_OPENAI_ENDPOINT` (optional — if set, uses Azure client)
- `MODEL_NAME` (default: `gpt-4o-mini`)
- `API_VERSION` (for Azure, default: `2024-07-01-preview`)

---

## 3. Deliverable 2: `README.md`

Three sections as requested:

| Section | Content |
|---|---|
| **Concept Design** | Problem statement, architecture diagram (text-based), tool/function overview, how few-shot + chain-of-thought prompting is structured, mock data schema |
| **How It's Implemented** | Walkthrough of the code: data layer → tool definitions → function-call execution loop → conversation management → CLI. Explanation of key patterns (function calling roundtrip, message history, policy validation logic) |
| **Usage Guide** | Prerequisites, installation (`pip install openai`), environment setup, interactive mode, demo mode (`--demo`), CLI commands (`/help`, `/quit`, `/log`, `/clear`), test case scenarios from the document, troubleshooting tips |

---

## 4. Test Coverage (from document)

| Test ID | How It's Met |
|---|---|
| TC_01 | Ask any policy question → `query_expense_policy` tool fires → accurate reply from mock FAQs |
| TC_02 | Provide or reference expenses → `calculate_reimbursement` tool fires → policy-capped total returned |
| TC_03 | Enter partial expense (missing category/amount) → `submit_expense` returns validation error with guidance |
| TC_04 | Multi-turn session — submit expense, then ask for reimbursement, then delete — all context preserved across turns |

---

## 5. File Layout

```
expense_chatbot/
├── expense_chatbot.py    # Single self-contained Python script
└── README.md             # Concept design, implementation explanation, usage guide
```

---

## 6. 5-Why Analysis — Plan Verification

### WHY CHAIN 1: Deliverables

**Why 1:** The plan delivers `expense_chatbot.py` and `README.md`. Does that satisfy the deliverables section?
→ The document (§46-52) requires: (a) defined problem + mock data, (b) prompt templates with few-shot + chain-of-thought, (c) complete SDK code with function calling/batching/message management, (d) tested conversation logs, (e) team presentation.

**Why 2:** Where are deliverables (a), (d), and (e)?
→ (a) is embedded in the script but not explicit as a standalone artifact. (d) — tested conversation logs — are only implied via `--demo` output, not saved to file. (e) is outside scope of code.

**Why 3:** Why aren't tested conversation logs saved automatically?
→ The plan mentions `/log` command and `--demo` flag but doesn't guarantee the output is captured in a structured, reusable format (e.g., JSON file) that proves TC_01–TC_04 were executed.

**Why 4:** Why does the `--demo` mode matter?
→ The workshop deliverable explicitly asks for "Tested conversation logs demonstrating multi-turn dialogue with context." Without automated log capture, there's no artifact to present.

**Why 5:** What's the root gap?
→ **Gap found:** The plan needs to explicitly save demo-mode output to a `conversation_logs.json` (or similar) so the test cases produce a reviewable artifact.

---

### WHY CHAIN 2: Batching

**Why 1:** The document (§9, §41) explicitly calls out **batching** as an OpenAI SDK feature to use.
→ The plan mentions "batching" nowhere in the implementation details.

**Why 2:** Why is batching absent from the tool design?
→ None of the 6 tools or design decisions reference batching. It's listed as a workshop requirement but has no corresponding implementation hook.

**Why 3:** Why does this matter?
→ Batching is one of the four explicitly named SDK features (function calling, batching, message management, output formatting). Omitting it means the plan doesn't meet the "Complete OpenAI SDK-based chatbot code implementing..." deliverable.

**Why 4:** Where could batching fit?
→ When a user asks for reimbursement across multiple employees or departments, the chatbot could batch multiple tool calls or multiple API requests. The `get_department_summary` tool could internally batch requests per employee.

**Why 5:** What's the root gap?
→ **Gap found:** The plan needs a concrete batching scenario — either via parallel tool calls (multiple function calls in one response) or explicit batch API usage for bulk operations (e.g., "calculate reimbursement for all employees").

---

### WHY CHAIN 3: Output Formatting

**Why 1:** The document (§25-29) calls out "output formatting techniques" as part of the Python SDK usage.
→ The plan doesn't mention output formatting as a design element.

**Why 2:** What does "output formatting" mean in context?
→ The document refers to structured, well-presented output — markdown tables, formatted receipts, clear separation of tool-call results vs. conversational replies.

**Why 3:** Why is this missing?
→ The plan mentions "color-coded output" for CLI but doesn't describe how the chatbot formats expense reports (tables), policy answers (bullet lists), or multi-tool responses.

**Why 4:** What's the impact?
→ Without structured output formatting, the chatbot's responses are just plain text blobs, not the polished, readable format expected for an "Expense Reporting Assistant."

**Why 5:** What's the root gap?
→ **Gap found:** The plan should specify output formatting: expense tables, policy bullet points, receipt summaries, and structured JSON for programmatic consumption.

---

### WHY CHAIN 4: Few-Shot Prompting

**Why 1:** The plan says "few-shot examples in system prompt." How are they structured?
→ The plan references embedding example dialogues but doesn't detail how they're organized or what they cover.

**Why 2:** Why does the structure matter?
→ The document (§49) requires "Well-crafted prompt templates using few-shot and chain-of-thought techniques with mock data." The quality of few-shot examples directly determines whether the model invokes the right tool.

**Why 3:** What's missing?
→ No specification of how many examples, which scenarios they cover (policy lookup vs. submission vs. reimbursement), or how they're parameterized with mock data values.

**Why 4:** Without scenario-specific examples, what happens?
→ The model may not learn to distinguish "What's the meal limit?" (use `query_expense_policy`) from "Calculate my reimbursement" (use `calculate_reimbursement`).

**Why 5:** What's the root gap?
→ **Gap found:** The plan needs to specify at least 3-4 few-shot examples covering each major intent: policy query, expense submission, reimbursement calculation, and multi-turn context. These should use mock data values explicitly.

---

### WHY CHAIN 5: Chain-of-Thought Prompting

**Why 1:** The plan says "chain-of-thought reasoning" in the system prompt. How?
→ Vaguely — "instructs the model to walk through policy rules step-by-step."

**Why 2:** Where does the chain-of-thought apply?
→ Only described for "complex queries" but not tied to specific tool flows.

**Why 3:** Why tie it to tool flows?
→ The document's example shows a reimbursement calculation that involves applying multiple rules (meal cap, taxi full, travel approved). The chain-of-thought should be embedded in how `calculate_reimbursement` explains its result.

**Why 4:** What's the difference?
→ Without CoT, the model returns "$1275.50." With CoT, it returns: "Meals: $45 (under $50 cap → $45.00), Taxi: $30.50 (fully reimbursed), Travel: $1200 (approved) → Total: $1275.50."

**Why 5:** What's the root gap?
→ **Gap found:** The plan needs to embed chain-of-thought in the reimbursement calculation flow so the model explains each line item's policy treatment before stating the total — matching the document's example logic.

---

### 5-Why Gaps Summary

| # | Gap | Fix |
|---|---|---|
| 1 | **Batching** — no concrete implementation of OpenAI batching / parallel tool calls | Add parallel tool calling scenario (e.g., multi-employee reimbursement) |
| 2 | **Conversation log artifact** — test cases not saved to file | `--demo` writes `conversation_logs.json` with full message history |
| 3 | **Output formatting** — no structured formatting design | Add markdown table formatting for expenses, bullet points for policies |
| 4 | **Few-shot examples** — not specified per intent | Define 3-4 explicit few-shot examples covering policy, submit, calculate, and multi-turn |
| 5 | **Chain-of-thought** — not tied to specific tool flow | Embed step-by-step reasoning in `calculate_reimbursement` response |

---

## 7. Revised Plan Additions (from 5-Why)

1. **Add `parallel_tool_calls: "auto"`** to the chat completion config so the model can call multiple tools in one turn (this is the modern OpenAI batching/parallelism mechanism).
2. **`--demo` mode** saves output to `conversation_logs.json` containing every message, tool call, and result for TC_01–TC_04.
3. **Output formatter** utility function that renders expenses as markdown tables, policies as bullet lists, and summaries as structured blocks.
4. **Few-shot prompt block** with explicit examples for each intent, parameterized with mock data values from the document.
5. **Chain-of-thought instruction** embedded in the `calculate_reimbursement` tool handler — the tool returns a breakdown dict per category before the total, and the model narrates it step-by-step.

---

## 8. Checklist Definition

### 8.1 Functionality

| # | Criterion | Source |
|---|---|---|
| F01 | Uses OpenAI SDK exclusively (Azure or standard) for chat completion | Doc §25-29 |
| F02 | Implements function calling with tool definitions | Doc §41, §139-165 |
| F03 | Implements batching / parallel tool calls | Doc §9, §41 |
| F04 | Implements conversation message management (history, context) | Doc §41 |
| F05 | Uses few-shot prompt templates with mock data | Doc §49 |
| F06 | Uses chain-of-thought reasoning in prompts | Doc §49 |
| F07 | Contains mock expense policy FAQs | Doc §64-69 |
| F08 | Contains mock expense report entries | Doc §71-78 |
| F09 | Implements reimbursement calculation with policy constraints | Doc §84-98 |
| F10 | Provides interactive CLI interface | Doc §43 |
| F11 | Handles ambiguous/incomplete input gracefully | Doc §199 (TC_03) |
| F12 | Policy validation on expense submission | Doc §65-68 |
| F13 | Output formatting (tables, bullets, structured blocks) | Doc §25 |

### 8.2 Test Cases

| # | Criterion | Source |
|---|---|---|
| T01 | TC_01: Ask about expense policies → accurate policy-based reply | Doc §199 |
| T02 | TC_02: Submit expenses → trigger reimbursement calculation | Doc §199 |
| T03 | TC_03: Handle ambiguous/incomplete expense details gracefully | Doc §199 |
| T04 | TC_04: Multi-turn conversation remembers context | Doc §199 |
| T05 | Conversation logs saved as artifact (JSON) | Doc §51 |

### 8.3 Deliverables

| # | Criterion | Source |
|---|---|---|
| D01 | Single self-contained Python script | User request |
| D02 | README.md with concept design | User request |
| D03 | README.md with implementation explanation | User request |
| D04 | README.md with usage guide | User request |
| D05 | Clearly defined real-world problem and mock data schema | Doc §46 |
| D06 | Well-crafted prompt templates (few-shot + CoT) with mock data | Doc §49 |
| D07 | Tested conversation logs demonstrating multi-turn dialogue | Doc §51 |

---

## 9. Self-Verification of the Plan Against the Checklist

| # | Criterion | Status | Evidence in Plan | Notes |
|---|---|---|---|---|
| F01 | OpenAI SDK exclusively | ✅ Covered | Uses `AzureOpenAI` or `OpenAI` client; env vars for config | Both Azure and standard modes supported |
| F02 | Function calling with tool definitions | ✅ Covered | 6 tools defined with JSON schemas | Explicit tool table in plan |
| F03 | Batching / parallel tool calls | ⚠️ Partially | Revised plan adds `parallel_tool_calls: "auto"` | Only added after 5-Why fix; no detailed scenario described |
| F04 | Conversation message management | ✅ Covered | Message window management (bounded history, default 20) | Clear |
| F05 | Few-shot prompt templates | ⚠️ Partially | Revised plan mentions "3-4 explicit few-shot examples" | Still vague on exact content and structure |
| F06 | Chain-of-thought reasoning | ⚠️ Partially | Revised plan embeds CoT in `calculate_reimbursement` breakdown | Only tied to one tool; not described for policy queries |
| F07 | Mock expense policy FAQs | ✅ Covered | `expense_policy_faqs` with 4+ rules | Matches doc examples |
| F08 | Mock expense report entries | ✅ Covered | `mock_expense_reports` with 3+ entries across 2 employees | Matches doc examples |
| F09 | Reimbursement calculation with policy constraints | ✅ Covered | Policy engine: meal cap $50, taxi full, travel approved | Matches doc logic |
| F10 | Interactive CLI interface | ✅ Covered | REPL with color-coded output, typed commands | Clear |
| F11 | Handle ambiguous/incomplete input | ⚠️ Partially | `submit_expense` returns validation errors | Only covers validation; no description of how conversational ambiguity is resolved |
| F12 | Policy validation on submission | ✅ Covered | Checks receipt, daily limits, pre-approval | Clear |
| F13 | Output formatting | ⚠️ Partially | Revised plan adds "markdown table formatting" | No specific format design described |
| T01 | TC_01: Policy query → accurate reply | ✅ Covered | `query_expense_policy` tool fires on policy questions | Matches doc |
| T02 | TC_02: Submit + trigger reimbursement | ✅ Covered | `submit_expense` + `calculate_reimbursement` flow | Matches doc |
| T03 | TC_03: Ambiguous input handling | ⚠️ Partially | Validation on `submit_expense` | No recovery dialog or clarification loop described |
| T04 | TC_04: Multi-turn context preserved | ✅ Covered | Bounded conversation history with 20-message window | Matches doc |
| T05 | Conversation logs saved as artifact | ✅ Covered | `--demo` writes `conversation_logs.json` | Added after 5-Why fix |
| D01 | Single Python script | ✅ Covered | `expense_chatbot.py` — single self-contained file | Clear |
| D02 | README concept design | ✅ Covered | README section: architecture, tools, prompting | Clear |
| D03 | README implementation explanation | ✅ Covered | README section: code walkthrough, patterns | Clear |
| D04 | README usage guide | ✅ Covered | README section: setup, modes, commands, troubleshooting | Clear |
| D05 | Defined problem + mock data schema | ✅ Covered | Problem statement and 3 mock data structures | Matches doc |
| D06 | Prompt templates (few-shot + CoT) | ⚠️ Partially | Described in design; few-shot examples not fully specified | Content exists as a concept, not detailed |
| D07 | Tested conversation logs | ✅ Covered | `--demo` mode → `conversation_logs.json` | Added after 5-Why fix |

---

## 10. Verification Summary

### 10.1 By Category

| Category | Total | ✅ Covered | ⚠️ Partially | ❌ Missing |
|---|---|---|---|---|
| Functionality | 13 | 7 | 6 | 0 |
| Test Cases | 5 | 3 | 2 | 0 |
| Deliverables | 7 | 6 | 1 | 0 |
| **Overall** | **25** | **16** | **9** | **0** |

### 10.2 9 Partially-Covered Items — Fixes Required

| Item | Gap | Fix Required |
|---|---|---|
| F03 | Batching has no concrete scenario | Define exact multi-tool scenario (e.g., "calculate reimbursement for all employees in Sales" → parallel calls to `get_employee_expenses` + `calculate_reimbursement`) |
| F05 | Few-shot examples are vague | Write the 3-4 exact few-shot message pairs with mock data values |
| F06 | CoT only on reimbursement | Extend CoT instruction to policy lookup too ("walk through matching rules before answering") |
| F11 | Ambiguity handling = validation only | Add clarification loop: "Did you mean Meals or Travel?" for ambiguous categories |
| F13 | Output format not designed | Specify table columns, policy bullet format, and receipt summary block |
| T03 | No recovery dialog for TC_03 | Add multi-turn clarification flow for missing fields |
| D06 | Few-shot/CoT templates not detailed | Document exact prompt template strings in README |

---

## 11. References

- **Workshop Document:** `docs/Workshop_2_Artifact/Workshop_2_Artifact.md`
- **OpenAI Python SDK (ChatCompletion, function calling, batching):** <https://platform.openai.com/docs/api-reference/chat/create>
- **Prompting Techniques (Few-shot, Chain-of-Thought):** <https://platform.openai.com/docs/guides/chat/prompt-design>
- **OpenAI Function Calling:** <https://platform.openai.com/docs/guides/gpt/function-calling>
